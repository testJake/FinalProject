package com.jquerykorea.poll;

import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jquerykorea.dto.Poll;

@Repository
public class PollDaoMybatis implements PollDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public Poll getPoll(String poll) {
		return sqlSession.getMapper(PollDao.class).getPoll(poll);
	}

	@Transactional
	@Override
	public int updatePoll(HashMap<String, Object> map) {
		return sqlSession.getMapper(PollDao.class).updatePoll(map);
	}

	@Override
	public int getCount() {
		return sqlSession.getMapper(PollDao.class).getCount();
	}

	@Override
	public void makePoll(HashMap<String, Object> map) {
		sqlSession.getMapper(PollDao.class).makePoll(map);
	}

}
