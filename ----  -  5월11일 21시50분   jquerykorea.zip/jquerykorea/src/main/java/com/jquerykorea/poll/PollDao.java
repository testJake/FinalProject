package com.jquerykorea.poll;

import java.util.HashMap;

import com.jquerykorea.dto.Poll;

public interface PollDao {

	public Poll getPoll(String poll);
	public int updatePoll(HashMap<String, Object> map);
	public int getCount();
	public void makePoll(HashMap<String,Object> map);
}
