package com.jquerykorea.user;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoginCheckAdvice {
	/*
	@Pointcut("execution(* com.acorn11.controller.UserController.list(..)) "
		+ "|| execution(* com.acorn11.controller.UserController.view(..)) "
		+ "|| execution(* com.acorn11.controller.UserController.modify(..)) "
		+ "|| execution(* com.acorn11.controller.UserController.remove(..))")
	public void loginCheckPointcut(){}
	*/
	@Pointcut("execution(* com.acorn11.controller..member*(..))")
		public void loginCheckPointcut(){}
	
	
	@Around("loginCheckPointcut()")
	public String loginCheck(ProceedingJoinPoint pJoinPoint) throws Throwable {
		//Ÿ�ٸ޼ҵ��� ��� �Ķ���� ������
		Object[] args=pJoinPoint.getArgs();
		
		//Ÿ�ٸ޼ҵ��� �Ķ���� �� HttpSession ��ü ������
		HttpSession session=null;
		for(Object param:args) {
			if(param instanceof HttpSession) {
				session=(HttpSession)param;
			}
		}
		
		String path="";
		if(session!=null && session.getAttribute("sessionId")==null) {
			path="user/user_error";
			//path="redirect:userLogin";
		} else {
			path=(String)pJoinPoint.proceed();
		}
		return path;
	}
}








