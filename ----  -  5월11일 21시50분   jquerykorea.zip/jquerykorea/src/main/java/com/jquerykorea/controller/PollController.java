package com.jquerykorea.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.poll.PollService;

@Controller
public class PollController {

	@Autowired
	private PollService pollService;
	
	@RequestMapping(value="/pollAction",method=RequestMethod.GET)
	public String poll(String option, Model model){

		if(pollService.getCount()==0){
			HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("polloption", "one");
			map.put("count", 10);
			pollService.makePoll(map);
			map.put("polloption", "two");
			map.put("count", 20);
			pollService.makePoll(map);
			map.put("polloption", "three");
			map.put("count", 15);
			pollService.makePoll(map);
			int optionOne = pollService.getPoll("one").getCount();
			int optionTwo = pollService.getPoll("two").getCount();
			int optionThree = pollService.getPoll("three").getCount();
			
			double hundred = 100;
		    double average = hundred/(optionOne+optionTwo+optionThree);
		    String aPercentage = String.format("%.2f",optionOne * average);
		    String bPercentage = String.format("%.2f",optionTwo * average);
		    String cPercentage = String.format("%.2f",optionThree * average);
		    
		    model.addAttribute("first", optionOne);
		    model.addAttribute("second", optionTwo);
		    model.addAttribute("third", optionThree);
		    model.addAttribute("aPercentage", aPercentage);
		    model.addAttribute("bPercentage", bPercentage);
		    model.addAttribute("cPercentage", cPercentage);
		    System.out.println("aaaa = " + aPercentage);
			return "poll/pollAction";
		}
		
		int count = pollService.getPoll(option).getCount();
		pollService.updatePoll(option, count);
		int optionOne = pollService.getPoll("one").getCount();
		int optionTwo = pollService.getPoll("two").getCount();
		int optionThree = pollService.getPoll("three").getCount();
		
		double hundred = 100;
	    double average = hundred/(optionOne+optionTwo+optionThree);
	    String aPercentage = String.format("%.2f",optionOne * average);
	    String bPercentage = String.format("%.2f",optionTwo * average);
	    String cPercentage = String.format("%.2f",optionThree * average);
	    
	    model.addAttribute("first", optionOne);
	    model.addAttribute("second", optionTwo);
	    model.addAttribute("third", optionThree);
	    model.addAttribute("aPercentage", aPercentage);
	    model.addAttribute("bPercentage", bPercentage);
	    model.addAttribute("cPercentage", cPercentage);
	    System.out.println("aaaa = " + aPercentage);
		return "poll/pollAction";
	}
}
