package com.jquerykorea.poll;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jquerykorea.dto.Poll;

@Service
public class PollServiceImpl implements PollService {

	@Autowired
	private PollDao pollDao;
	
	@Override
	public Poll getPoll(String poll) {
		
		return null;
	}

	@Override
	public int updatePoll(String option, int count) {
		// TODO Auto-generated method stub
		return 0;
	}

}
