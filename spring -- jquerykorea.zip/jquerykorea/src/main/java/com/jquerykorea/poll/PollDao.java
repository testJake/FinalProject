package com.jquerykorea.poll;

import com.jquerykorea.dto.Poll;

public interface PollDao {

	public Poll getPoll(String poll);
	public int updatePoll(String option, int count);
}
