package com.jquerykorea.poll;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jquerykorea.dto.Poll;

@Repository
public class PollDaoMybatis implements PollDao {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public Poll getPoll(String poll) {
		return sqlSession.getMapper(PollDao.class).getPoll(poll);
	}

	@Transactional
	@Override
	public int updatePoll(String option, int count) {
		return sqlSession.getMapper(PollDao.class).updatePoll(option, count);
	}

}
