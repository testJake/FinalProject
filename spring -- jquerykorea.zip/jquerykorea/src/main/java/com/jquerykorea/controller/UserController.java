package com.jquerykorea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.dto.User;
import com.jquerykorea.user.ExistsUserException;
import com.jquerykorea.user.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping("/index")
	public String welcome(){
		return "index";
	}
	
	@RequestMapping(value="/userJoin",method=RequestMethod.GET)
	public String write(){
		return "join/join";
	}
	
	@RequestMapping(value="/userJoin",method=RequestMethod.POST)
	public String write(User user, Model model){
		try{
			userService.insertUser(user);
		}catch(ExistsUserException e){
			model.addAttribute("msg", e.getMessage());
			return "join/join";
		}
		return "redirect:index";
	}
	
	
}
