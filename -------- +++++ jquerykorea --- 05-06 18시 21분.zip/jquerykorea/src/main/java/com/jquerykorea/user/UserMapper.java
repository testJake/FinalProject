package com.jquerykorea.user;

import java.util.List;

import com.jquerykorea.dto.User;

public interface UserMapper {

	public void insertUser(User user);
	public void updateUser(User user);
	public void deleteUser(String id);
	public User getUser(String id);
	public List<User> getUserList();
}
