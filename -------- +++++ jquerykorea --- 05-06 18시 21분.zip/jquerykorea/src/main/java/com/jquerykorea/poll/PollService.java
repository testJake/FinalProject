package com.jquerykorea.poll;

import com.jquerykorea.dto.Poll;

public interface PollService {

	public Poll getPoll(String poll);
	public int updatePoll(String option, int count);
}
