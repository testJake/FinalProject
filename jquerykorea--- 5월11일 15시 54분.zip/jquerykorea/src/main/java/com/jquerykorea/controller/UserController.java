package com.jquerykorea.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.board.BoardService;
import com.jquerykorea.dto.User;
import com.jquerykorea.user.ExistsUserException;
import com.jquerykorea.user.PasswordMissMatchException;
import com.jquerykorea.user.UserNotFoundException;
import com.jquerykorea.user.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping("/index")
	public String welcome(){
		return "index";
	}
	
	@RequestMapping(value="/userJoin",method=RequestMethod.GET)
	public String write(){
		return "join/join";
	}
	
	@RequestMapping(value="/userJoin",method=RequestMethod.POST)
	public String write(User user, Model model){
		try{
			userService.insertUser(user);
		}catch(ExistsUserException e){
			model.addAttribute("msg", e.getMessage());
			return "join/join";
		}
		return "redirect:index";
	}
	
	@RequestMapping(value="/userLogin",method=RequestMethod.POST)
	public String login(User user, Model model, HttpSession session){
		try{
			userService.login(user.getId(), user.getPassword());
			session.setAttribute("sessionId", user.getId());
			model.addAttribute("user", userService.getUser(user.getId()));
		}catch(UserNotFoundException | PasswordMissMatchException e){
			model.addAttribute("msg", e.getMessage());
			return "index";
		}
		return "index";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session){
		session.removeAttribute("sessionId");
		return "redirect:index";
	}
	
	@RequestMapping("/mypage")
	public String mypage(HttpSession session, Model model) throws UserNotFoundException{
		if(session.getAttribute("sessionId")==null) {
			return "error/errorPage";
		}
		String id = (String) session.getAttribute("sessionId");
        User user = userService.getUser(id);
		model.addAttribute("user", user);
		return "myPage/myPage";
	}
	
	@RequestMapping(value="/updateUser",method=RequestMethod.GET)
	public String updateGet(User user, Model model, HttpSession session){
		if(session.getAttribute("sessionId")==null) {
			return "error/errorPage";
		}
		return "myPage/myPage";
	}
	
	@RequestMapping(value="/updateUser",method=RequestMethod.POST)
	public String update(User user, Model model, HttpSession session){
		if(session.getAttribute("sessionId")==null) {
			return "error/errorPage";
		}
		userService.updateUser(user);
		boardService.updateName(user.getName(), user.getId());
		return "myPage/myPage";
	}
	
	@RequestMapping("/deleteUser")
	public String delete(String id, String password, HttpSession session){
		if(session.getAttribute("sessionId")==null) {
			return "error/errorPage";
		}
		userService.deleteUser(id, password);
			return "redirect:logout";
	}
}
