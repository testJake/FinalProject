package com.arrayList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayLIst_test {

	public static void main(String[]args){
		
		ArrayList<String> stringList = new ArrayList<String>();
		
		stringList.add("hello");
		stringList.add(new String("world"));
		stringList.add("java");
		stringList.add(new String("computer"));
		stringList.add("laptop");
		
		for(int i = 0; i < stringList.size(); i++){
			System.out.println(stringList.get(i));
		}
		System.out.println("==============");
		for(String list : stringList){
			System.out.println(list);
		}
        
		int sizeList = stringList.size();
		System.out.println(sizeList);
		
		int index = stringList.indexOf("world");
		System.out.println(index);
		
		System.out.println(stringList.contains("computer"));
		
		System.out.println(stringList.isEmpty());
		
		if(stringList.size() == 0){
			System.out.println("It is empty");
		}else {
			System.out.println("It has something in it");
		}
		
		stringList.remove(0);
		System.out.println(stringList);
		System.out.println("=======================");
		
		ArrayList<String> copyList = new ArrayList<String>();
		copyList.addAll(stringList);
		for(String list2 : copyList){
			System.out.println(list2);
		}
		System.out.println("=======================");
		copyList.set(0, "phone");
		for(String list2 : copyList){
			System.out.println(list2);
		}
		System.out.println("=======================1"
				+ "");
		
		String[] arrayString = new String[copyList.size()];
		arrayString = copyList.toArray(arrayString);
		for(String list3 : arrayString){
			System.out.println(list3);
		}
		System.out.println("=======================2");
		ArrayList<String> newList = new ArrayList<String>();
		for(int j =0 ; j < copyList.size(); j++){
			newList.add(arrayString[j]);
		}
		System.out.println(newList);
		System.out.println("------------------------");
		Iterator itr = newList.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		System.out.println("----------=----------=--------");
		//ArrayList stringList2 =  Arrays.asList(new String[]{"one","two","Three"});
		
		ListIterator listItr = newList
				.listIterator();
		while(listItr.hasNext()){
			System.out.println(listItr.next());
		}
		
	}
}
