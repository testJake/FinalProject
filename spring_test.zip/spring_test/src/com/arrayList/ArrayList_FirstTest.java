package com.arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayList_FirstTest {

	public static void main(String[]args){
		
		ArrayList<String> stringList = new ArrayList<String>();
	
		stringList.add("hello");
		stringList.add(new String("world"));
		stringList.add("java");
		stringList.add(new String("computer"));
		stringList.add("laptop");
		
		for(int i = 0; i < stringList.size(); i++){
			System.out.println(stringList.get(i));
		}
		
		for(String list : stringList){
			System.out.println(list);
		}
		
		int sizeList = stringList.size();
		System.out.println(sizeList);
		
		int index = stringList.indexOf("hello");
		System.out.println(index);
		
		System.out.println(stringList.contains("world"));
		
	    System.out.println(stringList.isEmpty());
	    
	    if(stringList.size() == 0){
	    	System.out.println("It is empty");
	    }else{
	    	System.out.println("It contains elememets");
	    }
	    
	    System.out.println(stringList.remove(0));
	    System.out.println("====================");
	    for(String list : stringList){
			System.out.println(list);
		}
	    
	    System.out.println(stringList.remove("laptop"));
	    System.out.println("====================");
	    for(String list : stringList){
			System.out.println(list);
		}
	    System.out.println("====================");
	    ArrayList<String> copyList = new ArrayList<String>();
	    copyList.addAll(stringList);
	    System.out.println(copyList);
	    
	    copyList.set(1, "earth");
	    System.out.println(copyList);
	    
	    /*copyList.clear();
	    System.out.println(copyList.isEmpty());*/
	    
	    String[] listArray = new String[copyList.size()];
	    listArray = copyList.toArray(listArray);
	    for(String aa : listArray){
	    	System.out.println(aa);
	    }
		System.out.println("-------------------");
		ArrayList<String> stringArray = new ArrayList<String>();
		for(int j = 0; j < listArray.length; j++){
			stringArray.add(listArray[j]);
		}
		System.out.println(stringArray);
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=");
		
		Iterator itr = stringArray.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		ListIterator listItr = stringArray.listIterator();
		while(listItr.hasNext()){
			System.out.println(listItr.next());
		}
		
	    Collections.sort(stringArray);
	    System.out.println(stringArray);
	}
	
}
