package coding.practice;

public class endUp_unsolved{

	public static void main(String[] args) {
		String str = "Hello";
		String result = endUp(str);

	}

	private static String endUp(String str) {
		if(str.length()<=3){
			return str.toUpperCase();
		}
		
		
	    
		
		return null; 
	}

}
