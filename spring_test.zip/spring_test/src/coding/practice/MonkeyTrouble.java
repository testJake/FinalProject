package coding.practice;

public class MonkeyTrouble {

	public static void main(String[]args){
		new MonkeyTrouble().test();
	}
	
	public void test(){
		boolean aSmile = false;
		boolean bSmile = false;
	    boolean result = monkeyTrouble(aSmile, bSmile);
	    System.out.println(result);
	}
	
	public boolean monkeyTrouble(boolean aSmile, boolean bSmile){
	    if((aSmile&&bSmile)||(!aSmile&&!
	    		bSmile)){
	    	return true;
	    }
	    return false;
	}
}
