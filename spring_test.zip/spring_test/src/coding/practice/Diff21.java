package coding.practice;

public class Diff21{

	public static void main(String[]args){
	//	new Diff21_unsolved().test();
		int num = 19;
		int result = new Diff21().diff21(num);
	}
	
	public int diff21(int n){
		if(n<=21 && n>=0){
			return 21-n;
		}else if(n>21){
			return (n-21)*2;
		}else{
			return 21+Math.abs(n);
		}
	}
	
	/*1.This is a Failed code.*/
	/*public void test(){
		int n = 2;
		int result = diff21(n);
		if(result == 0){
			System.out.println("The number you put is over 21");
		}
		System.out.println(result);
	}
	
	public int diff21(int n){
		if(n >= 21){
			return 0;
		}
		if(n < 21){
			n = 21 - n;
		}
		return n;
	}*/
}
