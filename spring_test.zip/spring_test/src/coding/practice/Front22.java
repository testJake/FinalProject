package coding.practice;

public class Front22 {

	public static void main(String[]args){
		String pass = "kitten";
		String result = new Front22().front22(pass);
		System.out.println(result);
	}
	
	public String front22(String str){
		if(str.length()<2){
			String passed = str.substring(0,str.length());
			return passed+str+passed;
		}
		String firstStr = str.substring(0, 2);
		return firstStr+str+firstStr;
	}
}
