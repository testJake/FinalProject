package coding.practice;

public class In1020 {

	public static void main(String[]args){
		int a = 12;
		int b = 99;
		boolean result = in1020(a, b);
		System.out.println(result);
	}
	
	public static boolean in1020(int a, int b){
		if((a>=10&&b<=20)||(a<=20&&b>=10)){
			if(a<=10&&b>=20){
				return false;
			}
			return true;
		}
		return false;
	}
}
