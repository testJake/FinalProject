package coding.practice;

public class LoneTeen {

	public static void main(String[]args){
		int a = 13;
		int b = 99;
		boolean result = loneTeen(a, b);
		System.out.println(result);
	}
	
	public static boolean loneTeen(int a, int b){
		if((a>=13&&a<=19)&&!(b>=13&&b<=19)){
			return true;
		}else if((b>=13&&b<=19)&&!(a>=13&&a<=19)){
			return true;
		}else{
			return false;
		}
	}
}
