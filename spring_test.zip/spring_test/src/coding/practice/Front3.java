package coding.practice;

public class Front3 {

	public static void main(String[]args){
		String str = "chocolate";
		String result = new Front3().front3(str);
		System.out.println(result);
	}
	
	public String front3(String str){
		if(str.length() <3){
			return str+str+str;
		}
		String newString = str.substring(0, 3);
	    return newString+newString+newString;
	}
}
