package coding.practice;

public class IntMax {

	/*Given three int values, a b c, return the largest. 

			intMax(1, 2, 3) �� 3
			intMax(1, 3, 2) �� 3
			intMax(3, 2, 1) �� 3*/
	
	public static void main(String[]args){
		int a = 1;
		int b = 2;
		int c = 3;
		int result = intMax(a, b, c);
		System.out.println(result);
	}
	
	public static int intMax(int a, int b, int c) {
		if(a>b&&a>c){
			return a;
		}else if(b>a&&b>c){
			return b;
		}else if(c>a&&c>b){
			return c;
		}else{
			return 0;
		}
	}
	
}
