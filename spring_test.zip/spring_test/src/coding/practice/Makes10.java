package coding.practice;

public class Makes10 {

	
	public static void main(String[]args){
		new Makes10().test();
	}
	
	public void test(){
		int a = 9;
		int b = 9;
		boolean result = makes10(a, b);
		System.out.println(result);
	}
	
	boolean makes10(int a, int b){	
		int sum = a + b;
		if(a==10||b==10||(sum==10)){
			return true;
		}else {
			return false;
		}
	}
}
