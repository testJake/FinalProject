package coding.practice;

public class FrontBack{

	public static void main(String[]args){
	//	new FrontBack_unsolved().test();
		String str = null;
		String result = new FrontBack().frontBack(str);
		System.out.println(result);
	}
	
	public String frontBack(String str){
		if(str==null) return "";
		if(str.length()<=1) return str;
		if(str.length()==2) return "" + str.charAt(1)+str.charAt(0);
		String result = "";
		result+= str.charAt(str.length()-1
				);
		for(int i = 1 ; i < str.length()-1; i++){
			result+=str.charAt(i);
		}
		result+= str.charAt(0);
		return result;
	}
	
	/*public void test(){
		String text = "main"
				+ "";
		String result = frontBack(text);
		System.out.println(result);
	}
	
	public String frontBack(String str){
		String firstString = str.substring(0);
		String lastString = str.substring(str.length()-1);
		char[] charList = str.toCharArray();
		char[] charList2 = new char[str.length()];
		for(int i = 0 ; i < charList.length ; i ++){
			if((charList[i] == firstString.charAt(0))){
				charList2[charList2.length-1] = firstString.charAt(0);
			}else if((charList[i] == lastString.charAt(0))){
				charList2[0] = lastString.charAt(0);
			}else{
				charList2[i] = charList[i];
			}
		}
		String result = String.valueOf(charList2);
		return result;
		
	} */
}
