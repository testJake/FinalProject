package coding.practice;

public class NearHundred{

	
	public static void main(String[]args){
		int number = 93;
		boolean result = nearHundred(number);
		System.out.println(result);
	}
	
	public static boolean nearHundred(int n){
		
		if(n<=110){
			if(n>=90){
				return true;
			}
		}
		if(n<=210){
			if(n>=190){
				return true;
			}
		}
		return false;
	}
}
