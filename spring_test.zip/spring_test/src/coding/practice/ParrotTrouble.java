package coding.practice;

public class ParrotTrouble{

	public static void main(String[]args){
		boolean talking = true;
		int hour = 6;
		boolean result = parrotTrouble(talking, hour);
	}

	private static boolean parrotTrouble(boolean talking, int hour) {
		
		if(talking==false){
			return false;
		}
		
		if(hour<7 || hour > 20){
			return true;
		}
		
		return false;
	}
}
