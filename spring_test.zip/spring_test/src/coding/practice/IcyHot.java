package coding.practice;

public class IcyHot {

	public static void main(String[]args){
		int temp1 = 120;
		int temp2 = -1;
		boolean result = icyHot(temp1, temp2);
		System.out.println(result);
	}
	
	public static boolean icyHot(int temp1, int temp2){
		
		if((temp1<=0&&temp2<=100)||(temp1>0&&temp2>100)){
			return false;
		}
		
		if((temp1<0||temp2<0)&&(temp1>100||temp2>100)){
			return true;
		}else if((temp1>0||temp2>0)&&(temp1<100||temp2<100)){
			return true;
		}else{
			return false;
		}
	}
}
