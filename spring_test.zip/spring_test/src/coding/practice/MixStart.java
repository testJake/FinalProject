package coding.practice;

public class MixStart {
	
/*	Return true if the given string begins with "mix", 
	except the 'm' can be anything, so "pix", "9ix" .. all count. 

	mixStart("mix snacks") �� true
	mixStart("pix snacks") �� true
	mixStart("piz snacks") �� false
	Go...Save, C*/

	public static void main(String[]args){
		String pass = "mix snacks";
		boolean result = mixStart(pass);
		System.out.println(result);
	}
	
	public static boolean mixStart(String str){
		if(str.length()<3){
			return false;
		}
		if((str.substring(1,3).equals("ix"))){
			return true;
		}
		
		return false;
		
	}
}
