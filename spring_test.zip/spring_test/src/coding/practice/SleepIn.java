package coding.practice;

public class SleepIn {
	
	public static void main(String[]args){
		new SleepIn().test();
	    
	     
	}
	
	void test(){
		boolean weekday = true;
		boolean vacation = false;
		boolean result =  sleepIn(weekday, vacation);
		System.out.println(result);
	}
	
    boolean sleepIn(boolean weekday, boolean vacation){
		if(!weekday || vacation){
			return true;
		}
		return false;
	}
}
