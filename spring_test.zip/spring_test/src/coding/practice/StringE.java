package coding.practice;

public class StringE {

	public static void main(String[]args){
		
		String str = "Hello";
		
		boolean result = new StringE().StringE(str);
		System.out.println(result);
	}
	
	public boolean StringE(String str ){
		if(!str.contains("e")) return false;
		int count = 0;
		
		char[] e = str.toCharArray();
		for(char a : e){
		   if(a =='e'){
			   count++;
		   }
		}
		if(count==1 || count==3){
			return true;
		}else {
			return false;
		}
		
	}
}
