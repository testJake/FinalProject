package coding.practice;

public class MissingChar {

	public static void main(String[]args){
		new MissingChar().test();
	}
	
	public void test(){
		String letter = "kitten";
		int index = 4;
		String result = missingChar(letter, index);
		System.out.println(result);
	}
	
	public String missingChar(String str, int n){
		int len = str.length();
		if(n > len){
			return "Out of boundaries of string lenth.";
		}
		String newStr = str.substring(n, n+1);
		String newString = str.replace(newStr, "");
		return newString;
	}
}
