package coding.practice;

public class HasTeen {

	public static void main(String[]args)
	{
		int a = 13;
		int b = 20;
		int c = 10;
		boolean result = hasTeen(a, b, c);
		System.out.println(result);
	}
	
	public static boolean hasTeen(int a, int b, int c){
		if((a>=13&&a<=19)||(b>=13&&b<=19)||(c>=13&&c<=19)){
		    return true;	
		}
		return false;
	}
}
