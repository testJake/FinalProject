package coding.practice;

public class NotString {

	public static void main(String[]args){
		new NotString().test();
	}
	
	public void test(){
		String not = "bad";
		String result = notString(not);
		System.out.println(result);
	}
	
	public String notString(String str){
		String original = str;
		if(original.length()<3){
			return "not " + original;
		}
		String containNot = str.substring(0, 3);
		if(containNot.equals("not")){
			return original;
		}else {
			return "not "+original;
		}
	}
}
