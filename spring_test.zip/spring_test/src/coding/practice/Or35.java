package coding.practice;

public class Or35 {

	public static void main(String[]args){
		int passNum = 7;
		boolean result = new Or35().or35(passNum);
		System.out.println(result);
	}
	
	public boolean or35(int n){
		if((n % 3 == 0)||(n % 5 == 0)){
			return true;
		}
		return false;
	}
}
