package coding.practice;

public class lastDigit {

	public static void main(String[] args) {
		int a = 7;
		int b = 17;
		boolean result = lastDigit(a,b);

	}

	private static boolean lastDigit(int a, int b) {
		if(a<b){
		if(a==b%10){
			return true;
		}
		} else {
			if(b==a%10){
				return true;
			}
			
		}
		return false;
	}

}
