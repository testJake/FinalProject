package coding.practice;

public class Close10 {

	
	public static void main(String[]args){
		int a = 8;
		int b = 13;
		int result = close10(a, b);
		System.out.println(result);
	}
	
	public static int close10(int a, int b) {
		if(Math.abs(10-a)>Math.abs(10-b)){
			return b;
		}else if(Math.abs(10-b)>Math.abs(10-a)){
			return a;
		}else{
			return 0;
		}
	}
}
