package coding.practice;

public class PosNeg{

	public static void main(String[]args){
		int a = 1;
		int b = -1;
		boolean negative = false;
		boolean result = posNeg(a,b,negative);
	}

	private static boolean posNeg(int a, int b, boolean negative) {
		
		if(negative==true && a<0 && b<0){
			return true;
		}
		if(negative==false){
		if(a<0 && b>0){
			return true;
		}
		
		if(a>0 && b<0){
			return true;
		}
		}
		return false;
	}
}
