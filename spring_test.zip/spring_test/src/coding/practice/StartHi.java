package coding.practice;

public class StartHi {

	public static void main(String[]args){
		String pass = "hello hi";
		boolean result = new StartHi().startHi(pass);
		System.out.println(result);
	}
	
	public boolean startHi(String str){
	
		if(str.length() < 2){
			return false;
		}
		
		String passed = str.substring(0,2);
		
		if(passed.equals("hi")){
			return true;
		}
		return false;
	}
}
