package coding.practice;

public class SumDouble {

	public static void main(String[]args){
		new SumDouble().test();
	}
	
	public void test(){
		int a = 3;
		int b = 2;
		int result = sumDouble(a, b);
		System.out.println(result);
	}
	
	public int sumDouble(int a, int b){
		if(a == b){
			return (a*2)+(b*2);
		}
		return a + b;
	}
}
