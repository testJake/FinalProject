package coding.practice;

public class BackAround {

	public static void main(String[]args){
		String passString = "a";
		String result = new BackAround().backAround(passString);
		System.out.println(result);
	}
	
	public String backAround(String str){
		String newString = str.substring(str.length()-1);
		return newString+str+newString;
	}
}
