package com.jquerykorea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.poll.PollService;

@Controller
public class PollController {

	@Autowired
	private PollService pollService;
	
	@RequestMapping(value="/pollAction",method=RequestMethod.GET)
	public String poll(String option, Model model){
		int count = pollService.getPoll(option).getCount();
		pollService.updatePoll(option, count);
		int optionOne = pollService.getPoll("one").getCount();
		int optionTwo = pollService.getPoll("two").getCount();
		int optionThree = pollService.getPoll("three").getCount();
		
		double hundred = 100;
	    double average = hundred/(optionOne+optionTwo+optionThree);
	    String aPercentage = String.format("%.2f",optionOne * average);
	    String bPercentage = String.format("%.2f",optionTwo * average);
	    String cPercentage = String.format("%.2f",optionThree * average);
	    
	    model.addAttribute("first", optionOne);
	    model.addAttribute("second", optionTwo);
	    model.addAttribute("third", optionThree);
	    model.addAttribute("aPercentage", aPercentage);
	    model.addAttribute("bPercentage", bPercentage);
	    model.addAttribute("cPercentage", cPercentage);
	    System.out.println("aaaa = " + aPercentage);
		return "poll/pollAction";
	}
}
