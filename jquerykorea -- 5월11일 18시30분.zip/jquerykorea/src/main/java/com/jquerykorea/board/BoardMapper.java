package com.jquerykorea.board;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jquerykorea.dto.Board;

public interface BoardMapper {
    public Integer getMaxNum();
	public void insertArticle(HashMap<String, Object> map);
	public void updateName(@Param("name") String name, @Param("id") String id);
	public void updateRe(HashMap<String, Object> map);
	public List<Board> getArticleList(HashMap<String, Object> map);
	public List<Board> getArticleListMenu(HashMap<String, Object> map);
	public Board getContent(int num);
	public void updateArticle(Board board);
	public void deleteArticle(String num);
	public int getTotalArticle();
	public int getTotalArticleMenu(HashMap<String, Object> map);
}
