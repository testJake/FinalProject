package com.jquerykorea.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jquerykorea.dto.Board;

@Service
public class BoardServiceImpl implements BoardService{

	@Autowired
	private BoardMapper boardMapper;
	
	@Override
	public Integer getMaxNum() {		
		int max = 0;
		if(boardMapper.getMaxNum() != null){
			max=boardMapper.getMaxNum();
		}
		return max;
	}

	@Override
	public void updateRe(HashMap<String, Object> map) {
		boardMapper.updateRe(map);		
	}
	
	@Override
	public void insertArticle(Board board) {
		int num=getMaxNum();
		num++;
		int ref=board.getRef();
		int reStep=board.getReStep();
		int reLevel=board.getReLevel();
		if(board.getNum()==0){
			ref=num;
		} else {
			HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("ref", ref);
			map.put("reStep", reStep);
			reStep++;
			reLevel++;
		}
		HashMap<String,Object> map2 = new HashMap<String,Object>();
		map2.put("num", num);
		map2.put("id", board.getId());
		map2.put("name", board.getName());
		map2.put("subject", board.getSubject());
		map2.put("content", board.getContent());
		map2.put("readCount", board.getReadCount());
		map2.put("ref", ref);
		map2.put("reStep", reStep);
		map2.put("reLevel", reLevel);		
		boardMapper.insertArticle(map2);
	}

	@Override
	public List<Board> getArticleList(String menu, String keyword, String pageNum) {
		HashMap<String,Object> map = new HashMap<String,Object>();
		String menu2=menu;
		if(menu2==null) menu2="";
		String keyword2=keyword;
		if(keyword2==null) keyword2="";
		String pageNumString=pageNum;
		if(pageNumString==null || pageNumString.equals("")){
			pageNumString="1";
		}
		int pageNum2=Integer.parseInt(pageNumString);
		int pageSize=5;
		int totalArticle;
		if(menu2=="" && keyword2==""){
			totalArticle=getTotalArticle();
		} else {
			totalArticle=getTotalArticleMenu(menu2, keyword2);
		}
		int totalPage=totalArticle/pageSize+(totalArticle%pageSize==0?0:1);
		if(pageNum2>totalPage){
			pageNum2=1;
		}
		int startRow=(pageNum2-1)*pageSize+1;
		int endRow=pageNum2*pageSize;
		if(endRow>totalArticle){
			endRow=totalArticle;
		}
		int number=totalArticle-(pageNum2-1)*pageSize;
		int blockSize=5;
		int startPage=(pageNum2/blockSize-(pageNum2%blockSize!=0?0:1))*blockSize+1;
		int endPage=startPage+blockSize-1;
		if(endPage>totalPage){
			endPage=totalPage;
		}

		map.put("startRow", startRow);
		map.put("endRow", endRow);
		map.put("menu", menu2);
		map.put("keyword", keyword2);
		getPagination(map);
		return boardMapper.getArticleList(map);
	}
    // Pagination �� �Ѱ��� startRow,endRow,menu,keyword ���   
	public ArrayList<String> getPagination(HashMap<String,Object> map){
		ArrayList<String> pageList = new ArrayList<String>();
		pageList.add((String) map.get("startRow"));
		pageList.add((String) map.get("endRow"));
		pageList.add((String) map.get("menu"));
		pageList.add((String) map.get("keyword"));
		return pageList;
	}
	
	@Override
	public int getTotalArticle() {
		return boardMapper.getTotalArticle();
	}
	
	@Override
	public int getTotalArticleMenu(String menu, String keyword) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("menu", menu);
		map.put("keyword", keyword);
		return boardMapper.getTotalArticleMenu(map);
	}
	
	@Override
	public void updateName(String name, String id) {
	    boardMapper.updateName(name,id);
	}

	@Override
	public Board getContent(int num) {
		return boardMapper.getContent(num);
	}

	@Override
	public void updateArticle(Board board) {
        boardMapper.updateArticle(board);
	}

	@Override
	public void deleteArticle(String num) {
		boardMapper.deleteArticle(num);
	}

}
