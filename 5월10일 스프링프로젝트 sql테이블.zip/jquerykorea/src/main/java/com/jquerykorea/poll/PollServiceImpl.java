package com.jquerykorea.poll;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jquerykorea.dto.Poll;

@Service
public class PollServiceImpl implements PollService {

	@Autowired
	private PollDao pollDao;
	
	@Override
	public Poll getPoll(String poll) {
		Poll returnPoll = pollDao.getPoll(poll);
		return returnPoll;
	}

	@Override
	public int updatePoll(String option, int count) {
		int row;
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("option", option);
		map.put("count", count);
		row = pollDao.updatePoll(map);
		return row;
	}

}
