package com.jquerykorea.user;

import java.util.List;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.jquerykorea.dto.User;

@Repository
public class UserDaoMybatis implements UserMapper {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Transactional
	@Override
	public void insertUser(User user) {
		sqlSession.getMapper(UserMapper.class).insertUser(user);
	}
    
	@Transactional
	@Override
	public void updateUser(User user) {
		sqlSession.getMapper(UserMapper.class).updateUser(user);
	}
    
	@Transactional
	@Override
	public void deleteUser(String id, String password) {
		sqlSession.getMapper(UserMapper.class).deleteUser(id,password);
	}

	@Override
	public User getUser(String id) {
		return sqlSession.getMapper(UserMapper.class).getUser(id);
	}

	@Override
	public List<User> getUserList() {
		return sqlSession.getMapper(UserMapper.class).getUserList();
	}

}
