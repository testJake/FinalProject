package jquerykorea;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.acorn.sql.RdbmsDAO;

public class PollDAO extends RdbmsDAO{

	private static PollDAO _poll;
	
	private PollDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static PollDAO getPollDAO(){
		if(_poll==null){
			_poll = new PollDAO();
		}
		return _poll;
	}
	
	public PollDTO getPoll(String poll){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int rows = 0;
		PollDTO pollDTO = new PollDTO();
		try{
			con = getConnection();
			
			String selection = "select * from poll where polloption=?";
			pstmt = con.prepareStatement(selection);
			pstmt.setString(1, poll);
			rs = pstmt.executeQuery();
			if(rs.next()){
				pollDTO = new PollDTO(rs.getString("polloption"), rs.getInt("count"));
			} 
			
		}catch(SQLException e){
			System.out.println("select error: "+e.getMessage());
		}finally{
			close(con, pstmt);
		}
		return pollDTO; 
	}
	
	public int updatePoll(String option, int count){
		Connection con = null;
		PreparedStatement pstmt = null;
		int rows = 0;
		try{
			con = getConnection();
			
			String sql = "update poll set count=?+1 where polloption=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, (count));
			pstmt.setString(2, option);
			rows = pstmt.executeUpdate();
			
		}catch(SQLException e){
			System.out.println("update error: "+e.getMessage());
		}finally{
			close(con, pstmt);
		}
		return rows;
	}
	
}
