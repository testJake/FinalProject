package com.jquerykorea.util;

//��������ȣ ��� �� ��ũ ����� �����ϱ� ���� Ŭ����
public class ThePager {
	private int pageNum;
	private int blockSize;
	private int totalPage;
	private String linkUrl;
	
	public ThePager(int pageNum, int blockSize, int totalPage, String linkUrl) {
		super();
		this.pageNum = pageNum;
		this.blockSize = blockSize;
		this.totalPage = totalPage;
		this.linkUrl = linkUrl;
	}

	@Override
	public String toString() {
		int startPage=(pageNum/blockSize)*blockSize+1;
		if(pageNum%blockSize==0) {
			startPage-=blockSize;
		}
		
		int endPage=startPage+blockSize-1;
		if(endPage>totalPage) {
			endPage=totalPage;
		}

		String html="";
		
		if(startPage>0) {		
			html+="<nav>";
			html+="<ul class=\"pagination\">";
			html+="<li>";
			if(startPage>blockSize) {
				html+="<a href="+linkUrl+"pageNum=1>ó��</a>";
				html+="<a href="+linkUrl+"pageNum="+(startPage-blockSize)+" aria-label=\"Previous\"><span aria-hidden=\"true\">&laquo;</span></a>";
			}
			html+="</li>";
			for(int i=startPage;i<=endPage;i++) {
				if(pageNum!=i) { 
					html+="<li><a href="+linkUrl+"pageNum="+i+">"+i+"</a></li>";
				} else {
					html+="<li><a>"+i+"</a></li>";
				} 
			}
			html+="<li>";
			if(endPage!=totalPage) { 
				html+="<a href="+linkUrl+"pageNum="+(startPage+blockSize)+" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a>";
				html+="<a href="+linkUrl+"pageNum="+totalPage+">������</a>";
			}
			html+="</li>";
			html+="</ul>";
			html+="</nav>";
		}
		return html;
	}
}






