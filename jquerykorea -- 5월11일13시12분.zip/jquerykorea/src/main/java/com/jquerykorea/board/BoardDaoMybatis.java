package com.jquerykorea.board;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jquerykorea.dto.Board;

@Repository
public class BoardDaoMybatis implements BoardMapper{

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public Integer getMaxNum() {
		return sqlSession.getMapper(BoardMapper.class).getMaxNum();
	}

	@Transactional
	@Override
	public void updateRe(HashMap<String, Object> map) {
		sqlSession.getMapper(BoardMapper.class).updateRe(map);	
	}
	
	@Transactional
	@Override
	public void insertArticle(HashMap<String, Object> map) {
		sqlSession.getMapper(BoardMapper.class).insertArticle(map);
	}

	@Override
	public List<Board> getArticleList(HashMap<String, Object> map) {
		return sqlSession.getMapper(BoardMapper.class).getArticleList(map);
	}
	@Override
	public List<Board> getArticleListMenu(HashMap<String, Object> map) {
		return sqlSession.getMapper(BoardMapper.class).getArticleListMenu(map);
	}

	@Override
	public void updateName(String name, String id) {
		sqlSession.getMapper(BoardMapper.class).updateName(name,id);	
	}

	@Override
	public Board getContent(int num) {
		return sqlSession.getMapper(BoardMapper.class).getContent(num);
	}

	@Override
	public void updateArticle(Board board) {
		sqlSession.getMapper(BoardMapper.class).updateArticle(board);
	}

	@Override
	public void deleteArticle(String num) {
        sqlSession.getMapper(BoardMapper.class).deleteArticle(num);
	}

	@Override
	public int getTotalArticle() {
		return sqlSession.getMapper(BoardMapper.class).getTotalArticle();
	}

	@Override
	public int getTotalArticleMenu(HashMap<String, Object> map) {
		return sqlSession.getMapper(BoardMapper.class).getTotalArticleMenu(map);
	}


}
