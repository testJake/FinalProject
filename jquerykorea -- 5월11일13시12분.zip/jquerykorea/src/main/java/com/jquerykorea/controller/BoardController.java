package com.jquerykorea.controller;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.board.BoardService;
import com.jquerykorea.dto.Board;
import com.jquerykorea.dto.User;
import com.jquerykorea.user.UserNotFoundException;
import com.jquerykorea.user.UserService;
import com.jquerykorea.util.ThePager;

@Controller
public class BoardController {

	@Autowired
	private UserService userService;
		
	private ThePager pager;
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/chatPage",method=RequestMethod.GET)
	public String chatPage(String num,String pageNum, Model model){
		Board board = boardService.getContent(Integer.parseInt(num));
		model.addAttribute("board", board);
		model.addAttribute("pageNum", pageNum);
		return "community/chatPage";
	}
	@RequestMapping(value="/chatWrite",method=RequestMethod.GET)
	public String write(Model model, HttpSession session,String menu, String keyword, String pageNum) throws UserNotFoundException{
		if(session.getAttribute("sessionId")==null) {
			return chatGet(model,menu,keyword,pageNum);
		}
		User user = userService.getUser((String)session.getAttribute("sessionId"));
		model.addAttribute("user", user);
		return "community/chatWrite";
	}
	@RequestMapping(value="/chatInsert",method=RequestMethod.POST)
	public String writeChat(Board board ,Model model,String menu, String keyword, String pageNum) {
		boardService.insertArticle(board);
		return chatGet(model,menu,keyword,pageNum);
	}
	@RequestMapping(value="/chatModify",method=RequestMethod.GET)
	public String chatModify(String num, Model model){
		Board board = boardService.getContent(Integer.parseInt(num));
		model.addAttribute("board", board);
		return "community/chatModify";
	}
	@RequestMapping(value="/chatModifyImpl",method=RequestMethod.POST)
	public String chatModify(Board board, Model model){
		boardService.updateArticle(board);
		int num = board.getNum();
		Board board2 = boardService.getContent(num);
		model.addAttribute("board", board2);
		return "community/chatPage";
	}
	@RequestMapping("/chatDelete")
	public String chatDelete(String num, Model model,String menu, String keyword, String pageNum){
		boardService.deleteArticle(num);
		return chatGet(model,menu,keyword,pageNum);
	}
	
	
	@RequestMapping(value="/chat",method=RequestMethod.GET)
	public String chatGet(Model model, String menu, String keyword, String pageNum){
		HashMap<String,Object> map = new HashMap<String,Object>();
		String menu2=menu;
		if(menu2==null) menu2="";
		String keyword2=keyword;
		if(keyword2==null) keyword2="";		
		String pageNumString=pageNum;
		if(pageNumString==null || pageNumString.equals("")){
			pageNumString="1";
		}
		int pageNum2=Integer.parseInt(pageNumString);
		int pageSize=5;
		int totalArticle;
		if(menu2=="" && keyword2==""){
		    totalArticle=boardService.getTotalArticle();
		} else {
			totalArticle=boardService.getTotalArticleMenu(menu2, keyword2);
		}
		int totalPage=totalArticle/pageSize+(totalArticle%pageSize==0?0:1);
		if(pageNum2>totalPage){
			pageNum2=1;
		}
		int startRow=(pageNum2-1)*pageSize+1;
		int endRow=pageNum2*pageSize;
		if(endRow>totalArticle){
			endRow=totalArticle;
		}
		map.put("startRow", startRow);
		map.put("endRow", endRow);
		map.put("menu", menu2);
		map.put("keyword", keyword2);
		if(menu2.equals("")){
		  model.addAttribute("boardList", boardService.getArticleList(map)); 
		  model.addAttribute("pageNum", pageNum2);
		} else {
		  model.addAttribute("boardList", boardService.getArticleListMenu(map));
		  model.addAttribute("pageNum", pageNum2);
		}
		int blockSize=5;
		pager=null;
		if(menu2.equals("")){
			pager=new ThePager(pageNum2,blockSize,totalPage,"chat?");
		}else{
			pager=new ThePager(pageNum2,blockSize,totalPage,"chat?menu="+menu2+"&keyword="+keyword2+"&");
		}
		model.addAttribute("pager", pager);
		return "community/communityChat";
	}
	
	@RequestMapping(value="/chatReply",method=RequestMethod.GET)
	public String chatReply(int num, String pageNum, int ref, int reStep, int reLevel, HttpSession session,Model model,String menu,String keyword) throws UserNotFoundException{
		if(session.getAttribute("sessionId")==null) {
			return chatGet(model,menu,keyword,pageNum);
		}
		String id = (String) session.getAttribute("sessionId");
		User user = userService.getUser(id);
		model.addAttribute("user", user);
	    model.addAttribute("num", num);
	    model.addAttribute("pageNum",pageNum);
	    model.addAttribute("ref", ref);
	    model.addAttribute("reStep", reStep);
	    model.addAttribute("reLevel", reLevel);
	    model.addAttribute("menu", menu);
	    model.addAttribute("keyword", keyword);
		return "community/chatReply";
	}
	@RequestMapping(value="/chatReply",method=RequestMethod.POST)
	public String chatReplyPost(int num, String pageNum, int ref, int reStep, int reLevel, HttpSession session,Model model,String menu,String keyword){
		if(session.getAttribute("sessionId")==null) {
			return chatGet(model,menu,keyword,pageNum);
		}
		String id = (String) session.getAttribute("sessionId");
		model.addAttribute("id", id);
		Board getUserInfo = boardService.getContent(num);
		Board board = new Board();
		board.setId(id);
		board.setNum(num);
		
		return "community/chatReply";
	}
	
}
