package com.jquerykorea.board;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jquerykorea.dto.Board;

@Service
public class BoardServiceImpl implements BoardService{

	@Autowired
	private BoardMapper boardMapper;
	
	@Override
	public Integer getMaxNum() {		
		int max = 0;
		if(boardMapper.getMaxNum() != null){
			max=boardMapper.getMaxNum();
		}
		return max;
	}

	@Override
	public void updateRe(HashMap<String, Object> map) {
		boardMapper.updateRe(map);		
	}
	
	@Override
	public void insertArticle(Board board) {
		int num=getMaxNum();
		num++;
		int ref=board.getRef();
		int reStep=board.getReStep();
		int reLevel=board.getReLevel();
		if(board.getNum()==0){
			ref=num;
		} else {
			HashMap<String,Object> map = new HashMap<String,Object>();
			map.put("ref", ref);
			map.put("reStep", reStep);
			reStep++;
			reLevel++;
		}
		HashMap<String,Object> map2 = new HashMap<String,Object>();
		map2.put("num", num);
		map2.put("id", board.getId());
		map2.put("name", board.getName());
		map2.put("subject", board.getSubject());
		map2.put("content", board.getContent());
		map2.put("readCount", board.getReadCount());
		map2.put("ref", ref);
		map2.put("reStep", reStep);
		map2.put("reLevel", reLevel);		
		boardMapper.insertArticle(map2);
	}

	@Override
	public List<Board> getArticleList(HashMap<String, Object> map) {
		return boardMapper.getArticleList(map);
	}

	
	@Override
	public int getTotalArticle() {
		return boardMapper.getTotalArticle();
	}
	
	@Override
	public int getTotalArticleMenu(String menu, String keyword) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		
		return 0;
	}
	
	@Override
	public void updateName(String name, String id) {
	    boardMapper.updateName(name,id);
	}

	@Override
	public Board getContent(int num) {
		return boardMapper.getContent(num);
	}

	@Override
	public void updateArticle(Board board) {
        boardMapper.updateArticle(board);
	}

	@Override
	public void deleteArticle(String num) {
		boardMapper.deleteArticle(num);
	}

}
