package com.jquerykorea.board;

import java.util.HashMap;
import java.util.List;

import com.jquerykorea.dto.Board;

public interface BoardService {
    public Integer getMaxNum();
	public void insertArticle(Board board);
	public void updateName(String name, String id);
	public void updateRe(HashMap<String, Object> map);
	public List<Board> getArticleList(HashMap<String, Object> map);
	public Board getContent(int num);
	public void updateArticle(Board board);
	public void deleteArticle(String num);
	public int getTotalArticle();
	public int getTotalArticleMenu(String menu, String keyword);
}
