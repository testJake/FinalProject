package com.jquerykorea.dto;
 
public class Board {
    private int num;
    private String id;
    private String name;
    private String subject;
    private String content;
    private String regDate;
    private int readCount;
    private int ref;
    private int reStep;
    private int reLevel;
	
    public Board() {
		// TODO Auto-generated constructor stub
	}

	public Board(int num, String name, String subject, String content, String regDate, int readCount, int ref,
			int reStep, int reLevel) {
		super();
		this.num = num;
		this.name = name;
		this.subject = subject;
		this.content = content;
		this.regDate = regDate;
		this.readCount = readCount;
		this.ref = ref;
		this.reStep = reStep;
		this.reLevel = reLevel;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public int getReadCount() {
		return readCount;
	}

	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}

	public int getRef() {
		return ref;
	}

	public void setRef(int ref) {
		this.ref = ref;
	}

	public int getReStep() {
		return reStep;
	}

	public void setReStep(int reStep) {
		this.reStep = reStep;
	}

	public int getReLevel() {
		return reLevel;
	}

	public void setReLevel(int reLevel) {
		this.reLevel = reLevel;
	}
    
    
}
