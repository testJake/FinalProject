package com.jquerykorea.dto;

public class Poll {
  private String pollOption;
  private int count;
  
  public Poll() {
	// TODO Auto-generated constructor stub
  }

public Poll(String pollOption, int count) {
	super();
	this.pollOption = pollOption;
	this.count = count;
}

public String getPollOption() {
	return pollOption;
}

public void setPollOption(String pollOption) {
	this.pollOption = pollOption;
}

public int getCount() {
	return count;
}

public void setCount(int count) {
	this.count = count;
}
  
  
}
