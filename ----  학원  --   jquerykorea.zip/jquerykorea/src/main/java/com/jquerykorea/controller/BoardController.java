package com.jquerykorea.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.board.BoardService;
import com.jquerykorea.dto.Board;
import com.jquerykorea.dto.User;
import com.jquerykorea.user.UserNotFoundException;
import com.jquerykorea.user.UserService;

@Controller
public class BoardController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/chatPage",method=RequestMethod.GET)
	public String chatPage(String num, Model model){
		Board board = boardService.getContent(Integer.parseInt(num));
		model.addAttribute("board", board);
		return "community/chatPage";
	}
	@RequestMapping(value="/chatWrite",method=RequestMethod.GET)
	public String write(Model model, HttpSession session,String menu, String keyword, String pageNum) throws UserNotFoundException{
		if(session.getAttribute("sessionId")==null) {
			return chatGet(model,menu,keyword,pageNum);
		}
		User user = userService.getUser((String)session.getAttribute("sessionId"));
		model.addAttribute("user", user);
		return "community/chatWrite";
	}
	@RequestMapping(value="/chatInsert",method=RequestMethod.POST)
	public String writeChat(Board board ,Model model,String menu, String keyword, String pageNum) {
		boardService.insertArticle(board);
		return chatGet(model,menu,keyword,pageNum);
	}
	@RequestMapping(value="/chatModify",method=RequestMethod.GET)
	public String chatModify(String num, Model model){
		Board board = boardService.getContent(Integer.parseInt(num));
		model.addAttribute("board", board);
		return "community/chatModify";
	}
	@RequestMapping(value="/chatModifyImpl",method=RequestMethod.POST)
	public String chatModify(Board board, Model model){
		boardService.updateArticle(board);
		int num = board.getNum();
		Board board2 = boardService.getContent(num);
		model.addAttribute("board", board2);
		return "community/chatPage";
	}
	@RequestMapping("/chatDelete")
	public String chatDelete(String num, Model model,String menu, String keyword, String pageNum){
		boardService.deleteArticle(num);
		return chatGet(model,menu,keyword,pageNum);
	}
	
	
	@RequestMapping(value="/chat",method=RequestMethod.GET)
	public String chatGet(Model model, String menu, String keyword, String pageNum){
		model.addAttribute("boardList", boardService.getArticleList(menu, keyword, pageNum)); 
		return "community/communityChat";
	}
	
}
