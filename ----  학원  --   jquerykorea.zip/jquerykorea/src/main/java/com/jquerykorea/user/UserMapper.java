package com.jquerykorea.user;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.jquerykorea.dto.User;

public interface UserMapper {

	public void insertUser(User user);
	public void updateUser(User user);
	public void deleteUser(@Param("id")String id, @Param("password")String password);
	public User getUser(String id);
	public List<User> getUserList();
}
