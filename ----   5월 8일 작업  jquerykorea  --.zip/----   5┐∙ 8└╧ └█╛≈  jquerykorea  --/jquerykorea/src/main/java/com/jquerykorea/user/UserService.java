package com.jquerykorea.user;

import java.util.List;

import com.jquerykorea.dto.User;

public interface UserService {
	public void insertUser(User user) throws ExistsUserException;
	public void updateUser(User user);
	public void deleteUser(String id, String password);
	public User getUser(String id) throws UserNotFoundException;
	public List<User> getUserList();
	void login(String id, String password) throws UserNotFoundException,PasswordMissMatchException;
}
