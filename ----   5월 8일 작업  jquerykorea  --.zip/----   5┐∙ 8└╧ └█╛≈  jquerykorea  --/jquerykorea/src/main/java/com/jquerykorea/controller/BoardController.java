package com.jquerykorea.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jquerykorea.board.BoardService;
import com.jquerykorea.dto.Board;
import com.jquerykorea.dto.User;
import com.jquerykorea.user.UserNotFoundException;
import com.jquerykorea.user.UserService;

@Controller
public class BoardController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/chatPage",method=RequestMethod.GET)
	public String chatPage(String num, Model model){
		Board board = boardService.getContent(Integer.parseInt(num));
		model.addAttribute("board", board);
		return "community/chatPage";
	}
	@RequestMapping(value="/chatWrite",method=RequestMethod.GET)
	public String write(Model model, HttpSession session) throws UserNotFoundException{
		if(session.getAttribute("sessionId")==null) {
			return chatGet(model);
		}
		User user = userService.getUser((String)session.getAttribute("sessionId"));
		model.addAttribute("user", user);
		return "community/chatWrite";
	}
	@RequestMapping(value="/chatInsert",method=RequestMethod.POST)
	public String writeChat(Board board ,Model model, HttpSession session) {
		boardService.insertArticle(board);
		return chatGet(model);
	}
	@RequestMapping(value="/chatModify",method=RequestMethod.GET)
	public String test2(){
		return "community/chatModify";
	}
	
	
	@RequestMapping(value="/chat",method=RequestMethod.GET)
	public String chatGet(Model model){
		model.addAttribute("boardList", boardService.getArticleList(1, 5, "", "")); 
		return "community/communityChat";
	}
	
}
