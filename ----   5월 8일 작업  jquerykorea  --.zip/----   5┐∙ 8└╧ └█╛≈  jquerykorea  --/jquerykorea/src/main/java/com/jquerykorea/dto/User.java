package com.jquerykorea.dto;

public class User {
   private String id;
   private String password;
   private String name;
   private String sex;
   private String email;
   private String joinDate;
   private String userLevel;
   
   public User() {
	// TODO Auto-generated constructor stub
}
   
public User(String id, String password, String name, String sex, String email, String joinDate, String userLevel) {
	super();
	this.id = id;
	this.password = password;
	this.name = name;
	this.sex = sex;
	this.email = email;
	this.joinDate = joinDate;
	this.userLevel = userLevel;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getSex() {
	return sex;
}

public void setSex(String sex) {
	this.sex = sex;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getJoinDate() {
	return joinDate;
}

public void setJoinDate(String joinDate) {
	this.joinDate = joinDate;
}

public String getUserLevel() {
	return userLevel;
}

public void setUserLevel(String userLevel) {
	this.userLevel = userLevel;
}
   
}
