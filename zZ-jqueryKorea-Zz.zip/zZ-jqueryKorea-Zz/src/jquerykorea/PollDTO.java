package jquerykorea;

public class PollDTO {

	private String polloption;
	private int count;
	
	public PollDTO() {
		// TODO Auto-generated constructor stub
	}

	public PollDTO(String polloption, int count) {
		super();
		this.polloption = polloption;
		this.count = count;
	}

	public String getPolloption() {
		return polloption;
	}

	public void setPolloption(String polloption) {
		this.polloption = polloption;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	
}
