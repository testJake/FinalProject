package com.jquerykorea.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jquerykorea.dto.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userDao;
	
	@Override
	public void insertUser(User user) throws ExistsUserException {
		if(userDao.getUser(user.getId())!=null){
			throw new ExistsUserException("�̹� �����ϴ� ���̵� �Դϴ�.");
		}
        userDao.insertUser(user);
	}

	@Override
	public void updateUser(User user) {
        userDao.updateUser(user);
	}

	@Override
	public void deleteUser(String id) {
		userDao.deleteUser(id);
	}

	@Override
	public User getUser(String id) throws UserNotFoundException {
		User user = userDao.getUser(id);
		if(user==null){
			throw new UserNotFoundException("�������� �ʴ� ����� �Դϴ�.");
		}
		return user;
	}

	@Override
	public List<User> getUserList() {
		return userDao.getUserList();
	}

	@Override
	public void login(String id, String password) throws UserNotFoundException, PasswordMissMatchException {
		User user=getUser(id);
		if(!user.getPassword().equals(password)){
			throw new PasswordMissMatchException("��й�ȣ�� ��ġ ���� �ʽ��ϴ�.");
		}

	}

}
