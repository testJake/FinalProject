package com.acorn.dto;

/*
desc mycomment
�̸�              ��        ����            
--------------- -------- ------------- 
COMMENT_NO      NOT NULL NUMBER(4)     
USER_ID                  VARCHAR2(20)  
COMMENT_CONTENT          VARCHAR2(100) 
COMMENT_DATE             DATE  
 */
public class MyComment1 {
	private int commentNo;
	private String userId;
	private String commentContent;
	private String commentDate;
	
	public MyComment1() {
		// TODO Auto-generated constructor stub
	}

	public MyComment1(int commentNo, String userId, String commentContent, String commentDate) {
		super();
		this.commentNo = commentNo;
		this.userId = userId;
		this.commentContent = commentContent;
		this.commentDate = commentDate;
	}

	public int getCommentNo() {
		return commentNo;
	}

	public void setCommentNo(int commentNo) {
		this.commentNo = commentNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCommentContent() {
		return commentContent;
	}

	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}

	public String getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
}
