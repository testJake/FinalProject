package com.acorn.dto;

/*
desc myreply
�̸�            ��        ����            
------------- -------- ------------- 
REPLY_NO      NOT NULL NUMBER(4)     
USER_ID                VARCHAR2(20)  
REPLY_CONTENT          VARCHAR2(100) 
REPLY_DATE             DATE          
COMMENT_NO             NUMBER(4)   
 */
public class MyReply {
	private int rNo;
	private String rId;
	private String rContent;
	private String rDate;
	private int cNo;
	
	public MyReply() {
		// TODO Auto-generated constructor stub
	}

	public MyReply(int rNo, String rId, String rContent, String rDate, int cNo) {
		super();
		this.rNo = rNo;
		this.rId = rId;
		this.rContent = rContent;
		this.rDate = rDate;
		this.cNo = cNo;
	}

	public int getrNo() {
		return rNo;
	}

	public void setrNo(int rNo) {
		this.rNo = rNo;
	}

	public String getrId() {
		return rId;
	}

	public void setrId(String rId) {
		this.rId = rId;
	}

	public String getrContent() {
		return rContent;
	}

	public void setrContent(String rContent) {
		this.rContent = rContent;
	}

	public String getrDate() {
		return rDate;
	}

	public void setrDate(String rDate) {
		this.rDate = rDate;
	}

	public int getcNo() {
		return cNo;
	}

	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
}
