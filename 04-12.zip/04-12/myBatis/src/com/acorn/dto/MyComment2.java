package com.acorn.dto;

/*
desc mycomment
�̸�              ��        ����            
--------------- -------- ------------- 
COMMENT_NO      NOT NULL NUMBER(4)     
USER_ID                  VARCHAR2(20)  
COMMENT_CONTENT          VARCHAR2(100) 
COMMENT_DATE             DATE  
 */ 
public class MyComment2 {
	private int num;
	private String id;
	private String content;
	private String regDate;
	
	public MyComment2() {
		// TODO Auto-generated constructor stub
	}

	public MyComment2(int num, String id, String content, String regDate) {
		super();
		this.num = num;
		this.id = id;
		this.content = content;
		this.regDate = regDate;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
}
