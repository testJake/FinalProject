package com.acorn.dto;

import java.util.List;

public class MyCommentUserReply2 {

	private MyComment3 comment;
	
	private List<MyReply> replies;
	
	public MyCommentUserReply2() {
		// TODO Auto-generated constructor stub
	}

	public MyCommentUserReply2(MyComment3 comment, List<MyReply> replies) {
		super();
		this.comment = comment;
		this.replies = replies;
	}

	public MyComment3 getComment() {
		return comment;
	}

	public void setComment(MyComment3 comment) {
		this.comment = comment;
	}

	public List<MyReply> getReplies() {
		return replies;
	}

	public void setReplies(List<MyReply> replies) {
		this.replies = replies;
	}
	
	
}
