package com.acorn.dto;

/*
desc myhewon
�̸�            ��        ����            
------------- -------- ------------- 
HEWON_ID      NOT NULL VARCHAR2(20)  
HEWON_NAME             VARCHAR2(20)  
HEWON_PHONE            VARCHAR2(20)  
HEWON_ADDRESS          VARCHAR2(50)  
HEWON_COUPON           VARCHAR2(100) 
HEWON_LEVEL            NUMBER(1)     
 */
public class MyHewon {
	private String id;
	private String name;
	private String phone;
	private String address;
	private String coupon;
	private int level;
	
	public MyHewon() {
		// TODO Auto-generated constructor stub
	}

	public MyHewon(String id, String name, String phone, String address, String coupon, int level) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.coupon = coupon;
		this.level = level;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
}
