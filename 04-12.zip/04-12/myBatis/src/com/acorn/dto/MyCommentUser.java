package com.acorn.dto;

public class MyCommentUser {
	//mycomment ���̺��� ������ �����ϱ� ���� �ʵ�
	private int num;
	private String id;
	private String content;
	private String regDate;
	//myuser ���̺��� ������ �����ϱ� ���� �ʵ�
	/*
	private String userId;
	private String userName;
	*/
	private MyUser user;//���԰�ü
	
	public MyCommentUser() {
		// TODO Auto-generated constructor stub
	}

	public MyCommentUser(int num, String id, String content, String regDate, MyUser user) {
		super();
		this.num = num;
		this.id = id;
		this.content = content;
		this.regDate = regDate;
		this.user = user;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public MyUser getUser() {
		return user;
	}

	public void setUser(MyUser user) {
		this.user = user;
	}
}
