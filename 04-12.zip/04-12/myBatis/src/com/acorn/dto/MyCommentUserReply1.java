package com.acorn.dto;

import java.util.List;

public class MyCommentUserReply1 {
	private int num;
	private String name;
	private String content;
	private String regDate;
	//�Խñۿ� ���� ��۸���� �����ϴ� �ʵ� => ���԰�ü
	private List<MyReply> replies;
	
	public MyCommentUserReply1() {
		// TODO Auto-generated constructor stub
	}

	public MyCommentUserReply1(int num, String name, String content, String regDate, List<MyReply> replies) {
		super();
		this.num = num;
		this.name = name;
		this.content = content;
		this.regDate = regDate;
		this.replies = replies;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public List<MyReply> getReplies() {
		return replies;
	}

	public void setReplies(List<MyReply> replies) {
		this.replies = replies;
	}
}
