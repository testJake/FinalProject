package com.acorn.userinfo;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class UserMapperDAO {
	private static UserMapperDAO _dao;
	
	private UserMapperDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static UserMapperDAO getDao() {
		if(_dao==null) {
			_dao=new UserMapperDAO();
		}
		return _dao;
	}
	
	private SqlSessionFactory getSqlSessionFactory() {
		String resource="myBatis-config.xml";
		InputStream inputStream=null;
		try {
			inputStream=Resources.getResourceAsStream(resource);
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		}
		return new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	public int addUser(UserDTO user) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper(UserMapper.class).addUser(user);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public UserDTO getUser(String userId) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			return sqlSession.getMapper(UserMapper.class).getUser(userId);
		} finally {
			sqlSession.close();
		}
	}
	
	public int modifyUser(UserDTO user) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper(UserMapper.class).modifyUser(user);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public int removeUser(String userId) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper(UserMapper.class).removeUser(userId);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public List<UserDTO> getUserList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			return sqlSession.getMapper(UserMapper.class).getUserList();
		} finally {
			sqlSession.close();
		}
	}
}
