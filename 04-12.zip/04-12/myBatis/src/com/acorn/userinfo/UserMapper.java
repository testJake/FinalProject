package com.acorn.userinfo;

import java.util.List;

public interface UserMapper {
	public int addUser(UserDTO user);
	public UserDTO getUser(String userId);
	public int modifyUser(UserDTO user);
	public int removeUser(String userId);
	public List<UserDTO> getUserList();
}
