package com.acorn.userinfo;

import java.util.List;

public class UserMapperService {
	private static UserMapperService _service;
	
	private UserMapperService() {
		// TODO Auto-generated constructor stub
	}
	
	public static UserMapperService getService() {
		if(_service==null) {
			_service=new UserMapperService();
		}
		return _service;
	}
	
	public void addUser(UserDTO user) throws ExistsUserException {
		if(UserMapperDAO.getDao().getUser(user.getUserId())!=null) {
			throw new ExistsUserException("�̹� �����ϴ� ���̵� �Է� �Ͽ����ϴ�.");
		}
		UserMapperDAO.getDao().addUser(user);
	}
	
	public UserDTO getUser(String userId) throws UserNotFoundException {
		UserDTO user=UserMapperDAO.getDao().getUser(userId);
		if(user==null) {
			throw new UserNotFoundException("["+userId+"] ���̵�� �������� �ʽ��ϴ�.");
		}
		return user;
	}
	
	public void login(String userId,String password) throws UserNotFoundException,PasswordMissMatchException {
		UserDTO user=getUser(userId);
		if(!user.getPassword().equals(password)) {
			throw new PasswordMissMatchException("��й�ȣ�� ���� �ʽ��ϴ�.");
		}
	}

	public List<UserDTO> getUserList() {
		return UserMapperDAO.getDao().getUserList();
	}
	
	public void modifyUser(UserDTO user) {
		UserMapperDAO.getDao().modifyUser(user);
	}
	
	public void removeUser(String userId) {
		UserMapperDAO.getDao().removeUser(userId);
	}
}
