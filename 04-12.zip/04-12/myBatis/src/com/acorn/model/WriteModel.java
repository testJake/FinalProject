package com.acorn.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.acorn.userinfo.ExistsUserException;
import com.acorn.userinfo.UserDTO;
import com.acorn.userinfo.UserMapperService;

public class WriteModel implements Action {
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//request.setCharacterEncoding("UTF-8");
		
		ActionForward forward=new ActionForward();
		UserDTO user=null;
		try {
			if(request.getMethod().equals("GET")) {
				throw new Exception();
			}
			
			String userId=request.getParameter("userId");
			String password=request.getParameter("password");
			String name=request.getParameter("name");
			String email=request.getParameter("email");
			
			user=new UserDTO(userId,password,name,email);
						
			UserMapperService.getService().addUser(user);			
			forward.setRedirect(true);
			forward.setPath("loginForm.do");
		} catch (ExistsUserException e) {
			request.setAttribute("msg", "�̹� �����ϴ� ���̵� �Է� �Ͽ����ϴ�.");
			request.setAttribute("user", user);
			forward.setRedirect(false);
			forward.setPath("user_write.jsp");
		} catch (Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		return forward;
	}

}
