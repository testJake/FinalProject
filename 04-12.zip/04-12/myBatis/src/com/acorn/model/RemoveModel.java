package com.acorn.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.acorn.userinfo.UserMapperService;

public class RemoveModel implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionForward forward=new ActionForward();
		
		try {
			if(request.getMethod().equals("GET")) {
				throw new Exception();
			}	

			String userId=request.getParameter("userId");
			
			UserMapperService.getService().removeUser(userId);
			
			HttpSession session=request.getSession();
			String sessionId=(String)session.getAttribute("sessionId");
			forward.setRedirect(true);
			if(sessionId.equals(userId)) {
				forward.setPath("logout.do");
			} else {
				forward.setPath("list.do");
			}
		} catch(Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		return forward;
	}

}
