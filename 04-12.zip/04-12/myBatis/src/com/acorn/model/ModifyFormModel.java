package com.acorn.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.acorn.userinfo.UserDTO;
import com.acorn.userinfo.UserMapperService;

public class ModifyFormModel implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionForward forward=new ActionForward();
		
		try {
			if(request.getMethod().equals("GET")) {
				throw new Exception();
			}

			String userId=request.getParameter("userId");
			UserDTO user=UserMapperService.getService().getUser(userId);
			request.setAttribute("user", user);
			forward.setRedirect(false);
			forward.setPath("user_modify.jsp");
		} catch(Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		
		return forward;
	}

}
