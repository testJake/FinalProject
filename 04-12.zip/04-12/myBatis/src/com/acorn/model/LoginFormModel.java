package com.acorn.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.acorn.userinfo.UserDTO;
import com.acorn.userinfo.UserMapperService;

public class LoginFormModel implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionForward forward=new ActionForward();
		
		HttpSession session=request.getSession();
		String sessionId=(String)session.getAttribute("sessionId");
		
		try {
			if(sessionId!=null) {
				UserDTO user=UserMapperService.getService().getUser(sessionId);
				request.setAttribute("user", user);
			}
			forward.setRedirect(false);
			forward.setPath("user_login.jsp");
		} catch(Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		return forward;
	}

}
