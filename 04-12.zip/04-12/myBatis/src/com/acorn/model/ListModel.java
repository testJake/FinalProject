package com.acorn.model;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.acorn.userinfo.UserDTO;
import com.acorn.userinfo.UserMapperService;

public class ListModel implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionForward forward=new ActionForward();
		
		try {
			HttpSession session=request.getSession();
			String sessionId=(String)session.getAttribute("sessionId");
			if(sessionId==null) {
				throw new Exception();
			}
			
			List<UserDTO> userList
				=UserMapperService.getService().getUserList();
			
			request.setAttribute("userList", userList);
		
			forward.setRedirect(false);
			forward.setPath("user_list.jsp");
		} catch(Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		
		return forward;
	}

}
