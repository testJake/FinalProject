package com.acorn.model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.acorn.userinfo.PasswordMissMatchException;
import com.acorn.userinfo.UserMapperService;
import com.acorn.userinfo.UserNotFoundException;

public class LoginModel implements Action {
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ActionForward forward=new ActionForward();
		
		String userId=null;
		try {
			if(request.getMethod().equals("GET")) {
				throw new Exception();
			}
			
			userId=request.getParameter("userId");
			String password=request.getParameter("password");
			
			UserMapperService.getService().login(userId, password);
		
			HttpSession session=request.getSession();
			session.setAttribute("sessionId", userId);
			
			forward.setRedirect(true);
			forward.setPath("loginForm.do");
		} catch(UserNotFoundException | PasswordMissMatchException e) {
			request.setAttribute("msg", e.getMessage());
			request.setAttribute("userId", userId);
			forward.setRedirect(false);
			forward.setPath("user_login.jsp");
		} catch(Exception e) {
			System.out.println("���� �޼��� = "+e.getMessage());
			forward.setRedirect(true);
			forward.setPath("error.do");
		}
		return forward;
	}
}
