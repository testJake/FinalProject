package com.acorn.dao;

import org.apache.ibatis.session.SqlSession;

import com.acorn.dto.MyReply;
import com.acorn.mapper.MyReplyMapper;

public class MyReplyDAO extends AbstractSession {
	private static MyReplyDAO _dao;
	
	private MyReplyDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static MyReplyDAO getDao() {
		if(_dao==null) {
			_dao=new MyReplyDAO();
		}
		return _dao;
	}
	
	public int insertReply(MyReply reply) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyReplyMapper.class).insertReply(reply);
		} finally {
			sqlSession.close();
		}
	}	
}
