package com.acorn.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.acorn.dto.MyUser;
import com.acorn.mapper.MyUserMapper;

public class MyUserDAO extends AbstractSession {
	private static MyUserDAO _dao;
	
	private MyUserDAO() {
		// TODO Auto-generated constructor stub
	}
	 
	public static MyUserDAO getDAO() {
		if(_dao==null) {
			_dao=new MyUserDAO();
		}
		return _dao;
	}
	
	public int insertUser(MyUser user) {
		//openSession(true) : autoCommit�� true�� ����
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyUserMapper.class).insertUser(user);
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyUser> getUserList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyUserMapper.class).getUserList();
		} finally {
			sqlSession.close();
		}
	}
}


