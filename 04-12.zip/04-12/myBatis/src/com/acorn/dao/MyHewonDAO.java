package com.acorn.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.acorn.dto.MyHewon;
import com.acorn.mapper.MyHewonMapper;

public class MyHewonDAO extends AbstractSession {
	private static MyHewonDAO _dao;
	
	private MyHewonDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static MyHewonDAO getDao() {
		if(_dao==null) {
			_dao=new MyHewonDAO();
		}
		return _dao;
	}
	
	public int insertHewon(MyHewon hewon) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).insertHewon(hewon);
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyHewon> getHewonList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getHewonList();
		} finally {
			sqlSession.close();
		}		
	}
	
	public List<MyHewon> getHewonDiscriminatorList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getHewonDiscriminatorList();
		} finally {
			sqlSession.close();
		}		
	}
	
	public List<MyHewon> getSearchLevelList(int level) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getSearchLevelList(level);
		} finally {
			sqlSession.close();
		}		
	}
	
	public int insertMapHewon(HashMap<String, Object> map) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).insertMapHewon(map);
		} finally {
			sqlSession.close();
		}
	}
	
	public String getSearchId1(HashMap<String, Object> map) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getSearchId1(map);
		} finally {
			sqlSession.close();
		}
	}
	
	public String getSearchId2(String name,String phone) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getSearchId2(name, phone);
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyHewon> getSearchHewonList(HashMap<String, Object> map) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyHewonMapper.class).getSearchHewonList(map);
		} finally {
			sqlSession.close();
		}		
	}
 }
