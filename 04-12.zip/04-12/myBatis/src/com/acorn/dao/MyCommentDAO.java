package com.acorn.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.acorn.dto.MyComment1;
import com.acorn.dto.MyComment2;
import com.acorn.dto.MyComment3;
import com.acorn.dto.MyCommentUser;
import com.acorn.dto.MyCommentUserReply1;
import com.acorn.dto.MyCommentUserReply2;
import com.acorn.mapper.MyCommentMapper;

public class MyCommentDAO extends AbstractSession {
	private static MyCommentDAO _dao;
	
	private MyCommentDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static MyCommentDAO getDao() {
		if(_dao==null) {
			_dao=new MyCommentDAO();
		}
		return _dao;
	}
	
	public int insertComment(MyComment1 comment) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).insertComment(comment);
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyComment1> getCommentList1() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentList1();
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyComment2> getCommentList2() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentList2();
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyComment3> getCommentList3() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentList3();
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyCommentUser> getCommentUserList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentUserList();
		} finally {
			sqlSession.close();
		}
	}
	
	public MyCommentUserReply1 getCommentUserReply1(int cnum) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentUserReply1(cnum);
		} finally {
			sqlSession.close();
		}
	}
	
	public MyCommentUserReply2 getCommentUserReply2(int cnum) {
		SqlSession sqlSession=getSqlSessionFactory().openSession(true);
		try {
			return sqlSession.getMapper(MyCommentMapper.class).getCommentUserReply2(cnum);
		} finally {
			sqlSession.close();
		}
	}
}
