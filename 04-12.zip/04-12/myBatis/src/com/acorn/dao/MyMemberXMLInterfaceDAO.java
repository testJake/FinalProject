package com.acorn.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.acorn.dto.MyMember;
import com.acorn.mapper.MyMemberInterfaceMapper;

public class MyMemberXMLInterfaceDAO {
private static MyMemberXMLInterfaceDAO _dao;
	
	private MyMemberXMLInterfaceDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static MyMemberXMLInterfaceDAO getDao() {
		if(_dao==null) {
			_dao=new MyMemberXMLInterfaceDAO();
		}
		return _dao;
	}
	
	private SqlSessionFactory getSqlSessionFactory() {
		String resource="myBatis-config.xml";
		InputStream inputStream=null;
		try {
			inputStream=Resources.getResourceAsStream(resource);
		} catch(IOException e) {
			throw new IllegalArgumentException(e);
		}
		return new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	public int insertMember(MyMember member) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper
				(MyMemberInterfaceMapper.class).insertMember(member);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public int updateMember(MyMember member) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper
				(MyMemberInterfaceMapper.class).updateMember(member);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public int deleteMember(String id) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			int rows=sqlSession.getMapper
				(MyMemberInterfaceMapper.class).deleteMember(id);
			if(rows>0) sqlSession.commit();
			else sqlSession.rollback();
			return rows;
		} finally {
			sqlSession.close();
		}
	}
	
	public List<MyMember> getMemberList() {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			return sqlSession.getMapper
				(MyMemberInterfaceMapper.class).getMemberList();
		} finally {
			sqlSession.close();
		}
	}
	
	public MyMember getMember(String id) {
		SqlSession sqlSession=getSqlSessionFactory().openSession();
		try {
			return sqlSession.getMapper
				(MyMemberInterfaceMapper.class).getMember(id);
		} finally {
			sqlSession.close();
		}
	}
}
