package com.acorn.mapper;

import java.util.List;

import com.acorn.dto.MyUser;

public interface MyUserMapper {
	public int insertUser(MyUser user);
	public List<MyUser> getUserList();
}
