package com.acorn.mapper;

import java.util.List;

import com.acorn.dto.MyComment1;
import com.acorn.dto.MyComment2;
import com.acorn.dto.MyComment3;
import com.acorn.dto.MyCommentUser;
import com.acorn.dto.MyCommentUserReply1;
import com.acorn.dto.MyCommentUserReply2;

public interface MyCommentMapper {
	public int insertComment(MyComment1 comment);
	public List<MyComment1> getCommentList1();
	public List<MyComment2> getCommentList2();
	public List<MyComment3> getCommentList3();
	public List<MyCommentUser> getCommentUserList();
	public MyCommentUserReply1 getCommentUserReply1(int cnum);
	public MyCommentUserReply2 getCommentUserReply2(int cnum);
}
