package com.acorn.mapper;

import com.acorn.dto.MyReply;

public interface MyReplyMapper {
	public int insertReply(MyReply reply);
}
