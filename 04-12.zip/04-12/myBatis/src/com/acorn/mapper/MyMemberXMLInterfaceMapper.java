package com.acorn.mapper;

import java.util.List;

import com.acorn.dto.MyMember;

public interface MyMemberXMLInterfaceMapper {
	public int insertMember(MyMember member);
	public int updateMember(MyMember member);
	public int deleteMember(String id);
	public List<MyMember> getMemberList();
	public MyMember getMember(String id);
}
